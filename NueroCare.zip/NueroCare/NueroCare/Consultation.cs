﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NueroCare
{
    public partial class Consultation : Form
    {
        private int _patientId;
        public Consultation(int patientId)
        {
            InitializeComponent();
            _patientId = patientId;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DBManager db = new NueroCare.DBManager();
            string sqlquery = "INSERT INTO Consultation ([PatientID], [PatientIn],[AppointmentDate],[Diagnosis],[Treatement],[Remark]) VALUES ( " + lblPatientID.Text + ",'" + cmbPatientFor.Text + "'," +
                    " GETDATE()," + "'" + txtDiagonosis.Text + "'," + "'" + txtTreatement.Text + "'," +
                    "'" + txtRemark.Text + "')";
            string error = string.Empty;
            db.ExecuteNonQuery(sqlquery, out error);
            if(string.IsNullOrEmpty(error))
            {
                MessageBox.Show("Saved Successfully");
                bindHistoryDetails();
            }
            else
            {
                MessageBox.Show(error);
            }
        }

        private void Consultation_Load(object sender, EventArgs e)
        {
            BindDetails();
            bindHistoryDetails();
            cmbPatientFor.SelectedIndex = 0;

        }

        private void bindHistoryDetails()
        {
            DBManager db = new NueroCare.DBManager();
            string sqlquery = "SELECT *  FROM Consultation  where patientID = " + lblPatientID.Text  ;
            DataSet ds = db.ExecuteDataSet(sqlquery);
            if (ds.Tables.Count > 0)
            {
                dataGridView1.DataSource = ds.Tables[0];

            }
        }

        private void BindDetails()
        {
            DBManager db = new NueroCare.DBManager();
            string sqlquery = "SELECT Id, PatientName, Sex, Age, Occupation,CellNo, Address, History, Allergies FROM PatientDetails  where [PatientName] LIKE '%" + txtPatientName.Text + "%'";
            DataSet ds = db.ExecuteDataSet(sqlquery);
            if (ds.Tables.Count > 0)
            {
                lblPatientID.Text = ds.Tables[0].Rows[0]["ID"].ToString();
                txtPatientName.Text = ds.Tables[0].Rows[0]["PatientName"].ToString();
                txtHistory.Text = ds.Tables[0].Rows[0]["History"].ToString();
                txtAllergies.Text = ds.Tables[0].Rows[0]["Allergies"].ToString();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0)
            {
                try
                {
                    cmbPatientFor.SelectedItem = dataGridView1.Rows[e.RowIndex].Cells["PatientIn"].Value.ToString();
                    txtDiagonosis.Text = dataGridView1.Rows[e.RowIndex].Cells["Diagnosis"].Value.ToString();
                    txtTreatement.Text = dataGridView1.Rows[e.RowIndex].Cells["Treatement"].Value.ToString();
                    txtRemark.Text = dataGridView1.Rows[e.RowIndex].Cells["Remark"].Value.ToString();
                    lblHistoryID.Text = dataGridView1.Rows[e.RowIndex].Cells["Id"].Value.ToString();
                }
                catch { }
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                try
                {
                    cmbPatientFor.SelectedItem = dataGridView1.Rows[e.RowIndex].Cells["PatientIn"].Value.ToString();
                    txtDiagonosis.Text = dataGridView1.Rows[e.RowIndex].Cells["Diagnosis"].Value.ToString();
                    txtTreatement.Text = dataGridView1.Rows[e.RowIndex].Cells["Treatement"].Value.ToString();
                    txtRemark.Text = dataGridView1.Rows[e.RowIndex].Cells["Remark"].Value.ToString();

                    lblHistoryID.Text = dataGridView1.Rows[e.RowIndex].Cells["Id"].Value.ToString();
                }
                catch { }
            }
        }

        private void ClearText()
        {
            cmbPatientFor.SelectedIndex = 0;
            txtDiagonosis.Text = string.Empty;
            txtTreatement.Text = string.Empty;
            txtRemark.Text = string.Empty;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearText();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DBManager db = new NueroCare.DBManager();
            string sqlquery = "DELETE  FROM Consultation  where Id = " + lblHistoryID.Text;
            string error = string.Empty;
            db.ExecuteNonQuery(sqlquery, out error);
            if (string.IsNullOrEmpty(error))
            {
                MessageBox.Show("Delted Successfully");
                bindHistoryDetails();
            }
            else
            {
                MessageBox.Show(error);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
