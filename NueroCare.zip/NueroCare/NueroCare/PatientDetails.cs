﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NueroCare
{
    public partial class PatientDetails : Form
    {
        DBManager db;
        public PatientDetails()
        {
            InitializeComponent();
        }
        private void PatientDetails_Load(object sender, EventArgs e)
        {
            BindDataGridView();
            ClearFields();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SavePatientDetails();
        }

        private void SavePatientDetails()
        {
            db = new NueroCare.DBManager();
            string sqlQuery = string.Empty;
            if (btnSave.Text == "Update")
            {
                sqlQuery = "UPDATE PatientDetails SET [PatientName] = '" +
                                    txtPatientName.Text + "', [Sex] = '" + cmbSex.SelectedItem + "' , [Age] = '" + txtAge.Text + "', [Occupation] = '" + cmbOccupation.Text +
                                 "', [CellNo] ='" + txtCellNo.Text + "', [Address] ='" + txtAddress.Text +
                                 "', [History] = '" + txtHistory.Text + "', [Allergies] = '" + txtAllergies.Text + "' WHERE Id =" + lblpatientID.Text ;
            }
            else
            {
                sqlQuery = "INSERT INTO PatientDetails ([PatientName], [Sex], [Age], [Occupation], [CellNo], [Address], [History], [Allergies] ) VALUES ('" +
              txtPatientName.Text + "','" + cmbSex.SelectedItem + "','" + txtAge.Text + "','" + cmbOccupation.Text + "','" + txtCellNo.Text + "','" + txtAddress.Text +
              "','" + txtHistory.Text + "','" + txtAllergies.Text + "')";
            }
            string ErrorStr = string.Empty;
            db.ExecuteNonQuery(sqlQuery, out ErrorStr);
            if (string.IsNullOrEmpty(ErrorStr))
            {
                MessageBox.Show("Patient Details Added Successfully!");
                BindDataGridView();
                ClearFields();
            }
        }

        private void BindDataGridView()
        {
            db = new NueroCare.DBManager();
            string sqlquery = "SELECT  Id, PatientName, Sex, Age, Occupation,CellNo, Address, History, Allergies FROM PatientDetails ";
            DataSet ds = db.ExecuteDataSet(sqlquery);
            dgvPatient.AutoGenerateColumns = false;

            if (ds.Tables.Count > 0)
                dgvPatient.DataSource = ds.Tables[0];

            
        }
        private void ClearFields()
        {
            lblpatientID.Text = "0";
            txtPatientName.Text = string.Empty;
            cmbSex.SelectedIndex = 0;
            txtAge.Text = string.Empty;
            cmbOccupation.SelectedIndex = 0;
            txtCellNo.Text = string.Empty;
            txtAddress.Text = string.Empty;
            txtHistory.Text = string.Empty;
            txtAllergies.Text = string.Empty;
            btnSave.Text = "Save";
            btnConsultation.Enabled = false;
        }

        private void txtPatientName_TextChanged(object sender, EventArgs e)
        {
            db = new NueroCare.DBManager();
            string sqlquery = "SELECT Id, PatientName, Sex, Age, Occupation,CellNo, Address, History, Allergies FROM PatientDetails  where [PatientName] LIKE '%" + txtPatientName.Text + "%'";
            DataSet ds = db.ExecuteDataSet(sqlquery);
            if (ds.Tables.Count > 0)
                dgvPatient.DataSource = ds.Tables[0];
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void dgvPatient_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                try
                {
                    lblpatientID.Text = dgvPatient.Rows[e.RowIndex].Cells["ID"].Value.ToString();
                    txtPatientName.Text = dgvPatient.Rows[e.RowIndex].Cells["PatientName"].Value.ToString();
                    cmbSex.SelectedItem = dgvPatient.Rows[e.RowIndex].Cells["Sex"].Value.ToString();
                    txtAge.Text = dgvPatient.Rows[e.RowIndex].Cells["Age"].Value.ToString();
                    cmbOccupation.SelectedItem = dgvPatient.Rows[e.RowIndex].Cells["Occupation"].Value.ToString();
                    txtCellNo.Text = dgvPatient.Rows[e.RowIndex].Cells["CellNo"].Value.ToString();
                    txtAddress.Text = dgvPatient.Rows[e.RowIndex].Cells["Address"].Value.ToString();
                    txtHistory.Text = dgvPatient.Rows[e.RowIndex].Cells["History"].Value.ToString();
                    txtAllergies.Text = dgvPatient.Rows[e.RowIndex].Cells["Allergies"].Value.ToString();

                    btnSave.Text = "Update";
                    btnConsultation.Enabled = true;
                }
                catch { }
            }
        }

        private void dgvPatient_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                try
                {

                    lblpatientID.Text = dgvPatient.Rows[e.RowIndex].Cells["ID"].Value.ToString();
                    txtPatientName.Text = dgvPatient.Rows[e.RowIndex].Cells["PatientName"].Value.ToString();
                    cmbSex.SelectedItem = dgvPatient.Rows[e.RowIndex].Cells["Sex"].Value.ToString();
                    txtAge.Text = dgvPatient.Rows[e.RowIndex].Cells["Age"].Value.ToString();
                    cmbOccupation.SelectedItem = dgvPatient.Rows[e.RowIndex].Cells["Occupation"].Value.ToString();
                    txtCellNo.Text = dgvPatient.Rows[e.RowIndex].Cells["CellNo"].Value.ToString();
                    txtAddress.Text = dgvPatient.Rows[e.RowIndex].Cells["Address"].Value.ToString();
                    txtHistory.Text = dgvPatient.Rows[e.RowIndex].Cells["History"].Value.ToString();
                    txtAllergies.Text = dgvPatient.Rows[e.RowIndex].Cells["Allergies"].Value.ToString();

                    btnSave.Text = "Update";
                    btnConsultation.Enabled = true;

                }
                catch { }
            }
        }

        private void BindFields(DataGridViewRow row)
        {
            //lblpatientID.Text = row.Cells["ID"].Value.ToString();
            //txtPatientName.Text = row.Cells["PatientName"].Value.ToString();
            //cmbSex.SelectedItem = row.Cells["Sex"].Value.ToString();
            //txtAge.Text = row.Cells["Age"].Value.ToString();
            //cmbOccupation.SelectedItem = row.Cells["Occupation"].Value.ToString();
            //txtCellNo.Text = row.Cells["CellNo"].Value.ToString();
            //txtAddress.Text = row.Cells["Address"].Value.ToString();
            //txtHistory.Text = row.Cells["History"].Value.ToString();
            //txtAllergies.Text = row.Cells["Allergies"].Value.ToString();


        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnConsultation_Click(object sender, EventArgs e)
        {
            Consultation obj = new NueroCare.Consultation(Convert.ToInt32(lblpatientID.Text));
            obj.MdiParent = ParentForm;
            obj.Show();
        }
    }
}
