﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Windows.Forms;
using System.Configuration;

namespace NueroCare
{
    public class DBManager
    {
        private string _connectionString;
        public DBManager()
        {
            _connectionString = (ConfigurationManager.ConnectionStrings["DbClinicConnectionString"].ConnectionString);

        }

        /// <summary>
        /// Fetch records from database, For SP string example EXEC SP_Name 'PARM1','PARM2'
        /// Having one ocurrences where multiple table return;
        /// Should Not be used for sigle table output.
        /// </summary>
        /// <param name="strSql"></param>
        /// <returns>mutiple data tables</returns>
        public DataSet ExecuteDataSet(string strSql)
        {
            string  ErrorStr = string.Empty;
            DataSet ds = new DataSet();
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    SqlCommand cmd = new SqlCommand(strSql, con);

                    SqlDataAdapter dap = new SqlDataAdapter(cmd);

                    con.Open();
                    cmd.CommandTimeout = 21600;
                    dap.Fill(ds);
                    con.Close();
                    return ds;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
                ErrorStr = ex.Message;
                //throw new Exception(ex.Message);
            }
            return ds;

        }

   
        /// <summary>
        /// Should be used for Insert and updated records only.
        /// </summary>
        /// <param name="strSql">string sql query</param>
        public int ExecuteNonQuery(string strSql, out string ErrorStr)
        {

            ErrorStr = string.Empty;
            int rowsAffected = 0;
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    SqlCommand cmd = new SqlCommand(strSql, con);
                    cmd.Connection.Open();
                    cmd.CommandTimeout = 21600;
                    rowsAffected = cmd.ExecuteNonQuery();
                    cmd.Connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
                ErrorStr = ex.Message;
                //throw new Exception(ex.Message);
            }
            return rowsAffected;
        }

    
     
        public int ExecuteQuerywithOutParameter(string strSql, Hashtable hTable, out string ErrorStr)
        {
            int RowsAffected = 0;
            ErrorStr = string.Empty;
            try
            {

                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    SqlCommand cmd = new SqlCommand(strSql, con);
                    if (hTable != null)
                    {
                        foreach (DictionaryEntry keyVal in hTable)
                        {
                            cmd.Parameters.AddWithValue((string)keyVal.Key, keyVal.Value);
                        }
                    }
                    cmd.Parameters.Add("@RowsAffected", SqlDbType.Int).Direction = ParameterDirection.Output;
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter dap = new SqlDataAdapter(cmd);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    RowsAffected = (int)(cmd.Parameters["@RowsAffected"].Value);
                    cmd.Connection.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
                ErrorStr = ex.Message;
                //throw new Exception(ex.Message);
            }

            return RowsAffected;
        }


    

       
        public DataSet ExecuteDataSetWithOutTimeOut(string strSql, Hashtable hTable, string connectionString, out string ErrorStr)
        {
            ErrorStr = string.Empty;
            DataSet ds = new DataSet();
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    SqlCommand cmd = new SqlCommand(strSql, con);
                    if (hTable != null)
                    {
                        foreach (DictionaryEntry keyVal in hTable)
                        {
                            cmd.Parameters.AddWithValue((string)keyVal.Key, keyVal.Value);
                        }
                    }
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter dap = new SqlDataAdapter(cmd);

                    con.Open();
                    dap.Fill(ds);
                    con.Close();
                    return ds;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
                ErrorStr = ex.Message;
            }
            return ds;
        }
        // #T3286


        public int ExecutedataForSaveImage(string strSql, Hashtable hTable, string connectionString)
        {
            Int32 ID = 0;
            try
            {

                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbClinicConnectionString"].ConnectionString))
                {
                    SqlCommand cmd = new SqlCommand(strSql, con);
                    if (hTable != null)
                    {
                        foreach (DictionaryEntry keyVal in hTable)
                        {
                            cmd.Parameters.AddWithValue((string)keyVal.Key, keyVal.Value);
                        }
                    }
                    //SqlParameter outPutVal = new SqlParameter("@CorpLogoId", SqlDbType.Int);
                    //outPutVal.Direction = ParameterDirection.Output;
                    //cmd.Parameters.Add(outPutVal);
                    cmd.Parameters.Add("@CorpLogoId", SqlDbType.Int).Direction = ParameterDirection.Output;
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter dap = new SqlDataAdapter(cmd);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    ID = Convert.ToInt32(cmd.Parameters["@CorpLogoId"].Value);
                    cmd.Connection.Close();
                    return ID;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

     

        public List<T> VectorInmyReadEntity<T>(string spName, Dictionary<string, object> spParms)//#T3401
        {
            List<T> RetVal = new List<T>();
            try
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbClinicConnectionString"].ConnectionString))
                {
                    // var orderDetails = con.Query<T>(sql).ToList();
                    using (SqlCommand cmd = new SqlCommand(spName, con))
                    {
                        if (spParms != null)
                        {
                            foreach (var keyVal in spParms)
                            {
                                cmd.Parameters.AddWithValue((string)keyVal.Key, keyVal.Value);
                            }
                        }
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 21600;
                        con.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            Type Entity = typeof(T);
                            Dictionary<string, PropertyInfo> PropDict = new Dictionary<string, PropertyInfo>();

                            if (dr != null && dr.HasRows)
                            {
                                //RetVal = new List<T>();
                                var Props = Entity.GetProperties(BindingFlags.Instance | BindingFlags.Public);
                                PropDict = Props.ToDictionary(p => p.Name.ToUpper(), p => p);
                                while (dr.Read())
                                {
                                    T newObject = Activator.CreateInstance<T>();
                                    for (int Index = 0; Index < dr.FieldCount; Index++)
                                    {
                                        if (PropDict.ContainsKey(dr.GetName(Index).ToUpper()))
                                        {
                                            var Info = PropDict[dr.GetName(Index).ToUpper()];
                                            if ((Info != null) && Info.CanWrite)
                                            {
                                                var Val = dr.GetValue(Index);
                                                Info.SetValue(newObject, (Val == DBNull.Value) ? null : Val, null);
                                            }
                                        }
                                    }
                                    RetVal.Add(newObject);
                                }
                            }
                        }
                    }
                    con.Close();
                }
            }
            catch (Exception ex)
            {
               throw new Exception(ex.Message);
            }

            return RetVal;
        }

        public DataSet ExecuteDataSetForSP(string spName, Dictionary<string, object> spParms)//#T3401
        {
            try
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbClinicConnectionString"].ConnectionString))
                {
                    SqlCommand cmd = new SqlCommand(spName, con);
                    if (spParms != null)
                    {
                        foreach (var keyVal in spParms)
                        {
                            cmd.Parameters.AddWithValue((string)keyVal.Key, keyVal.Value);
                        }
                    }
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 21600;
                    using (SqlDataAdapter dap = new SqlDataAdapter(cmd))
                    {
                        DataSet ds = new DataSet();
                        // con.Open();
                        dap.Fill(ds);
                        // con.Close();
                        return ds;
                    }
                }
            }

            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #region Conver Datatable to List

        public List<T> ConvertDataTable<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }
        public T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                        pro.SetValue(obj, dr[column.ColumnName] == DBNull.Value ? null : dr[column.ColumnName], null);
                    else
                        continue;
                }
            }
            return obj;
        }

        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }


        /// <summary>
        /// This Function convert data table to the model.
        /// </summary>
        /// <typeparam name="T">Modle</typeparam>
        /// <param name="dt">dataset table</param>
        /// <returns></returns>
        public List<T> ConvertDataTableToList<T>(DataTable dt)
        {
            var columnNames = dt.Columns.Cast<DataColumn>().Select(c => c.ColumnName.ToLower()).ToList();
            var properties = typeof(T).GetProperties();
            return dt.AsEnumerable().Select(row =>
            {
                var objT = Activator.CreateInstance<T>();
                foreach (var pro in properties)
                {
                    if (columnNames.Contains(pro.Name.ToLower()))
                    {
                        try
                        {
                            pro.SetValue(objT, row[pro.Name]);
                        }
                        catch (Exception ex) { }
                    }
                }
                return objT;
            }).ToList();
        }
        #endregion


        public void ExecuteNonQueryWithParam(string spName, Dictionary<string, object> spParms)//#T3401
        {
            try
            {
                using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DbClinicConnectionString"].ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(spName, con))
                    {
                        if (spParms != null)
                        {
                            foreach (var keyVal in spParms)
                            {
                                cmd.Parameters.AddWithValue((string)keyVal.Key, keyVal.Value);
                            }
                        }
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 21600;
                        con.Open();
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }

                    //return isExec;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

    }

    public class TableColumns
    {
        public string Text { get; set; }
        public string Value { get; set; }

    }
}
